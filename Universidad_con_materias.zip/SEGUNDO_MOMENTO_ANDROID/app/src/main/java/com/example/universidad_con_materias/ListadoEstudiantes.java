package com.example.universidad_con_materias;

public class ListadoEstudiantes {


        private String Identificacion;
        private String Nombre;
        private String Carrera;
        private String Semestre;
        private String Activo;

        public ListadoEstudiantes() {
        }

        public String getIdentificacion() {
            return Identificacion;
        }

        public void setIdentificacion(String identificacion) {
            Identificacion = identificacion;
        }

        public String getNombre() {
            return Nombre;
        }

        public void setNombre(String nombre) {
            Nombre = nombre;
        }

        public String getCarrera() {
            return Carrera;
        }

        public void setCarrera(String carrera) {
            Carrera = carrera;
        }

        public String getSemestre() {
            return Semestre;
        }

        public void setSemestre(String semestre) {
            Semestre = semestre;
        }

        public String getActivo() {
            return Activo;
        }

        public void setActivo(String activo) {
            Activo = activo;
        }

}


