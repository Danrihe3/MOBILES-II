package com.example.universidad_con_materias;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class AccesoUsuarios extends AppCompatActivity {
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    Button btnAcceder, btnCrearUsuario;
    EditText etUsuario, etContraseña;
    String Usuario, Contraseña;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btnAcceder=findViewById(R.id.btnAcceder);
        btnCrearUsuario=findViewById(R.id.btnCrearUsuario);
        etUsuario=findViewById(R.id.etUsuario);
        etContraseña=findViewById(R.id.etContraseña);
    }

    public void Acceder(View view){
        Usuario=etUsuario.getText().toString();
        Contraseña=etContraseña.getText().toString();
        if(!Usuario.isEmpty() && !Contraseña.isEmpty()){
            db.collection("Usuarios")
                    .whereEqualTo("Usuario", Usuario)
                    .whereEqualTo("Contraseña", Contraseña)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    cambiarActividad();
                                }
                            } else {
                                cambiarActividad();

                            }
                        }
                    });
        }else{
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
        }
    }

    public void crearUsuario(View view){
        Usuario=etUsuario.getText().toString();
        Contraseña=etContraseña.getText().toString();
        if(!Usuario.isEmpty() && !Contraseña.isEmpty()){
            //Search users
            db.collection("Usuarios")
                    .whereEqualTo("Usuario", Usuario)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (!task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Map<String, Object> acceso = new HashMap<>();
                                    acceso.put("Usuario", Usuario);
                                    acceso.put("Contraseña", Contraseña);

                                    db.collection("Usuarios")
                                            .add(acceso)
                                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                @Override
                                                public void onSuccess(DocumentReference documentReference) {
                                                    usuariosCreados();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    usuariosCreadosError();
                                                }
                                            });

                                }
                            } else {
                                usuariosExistentes();
                            }
                        }
                    });
        }else{
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
        }
    }





    //Mensajes Emergentes

    private void usuariosExistentes(){
        AlertDialog.Builder usuarioExistente=new AlertDialog.Builder(this);
        usuarioExistente.setTitle("El usuario ya existe");
        usuarioExistente.setMessage("Intenta con un usuario diferente o accede a tu cuenta.");
        usuarioExistente.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog DialogoNuevo=usuarioExistente.create();
        DialogoNuevo.show();
    }

    private void usuariosCreados(){
        AlertDialog.Builder usuarioCreado=new AlertDialog.Builder(this);
        usuarioCreado.setTitle("¡Usuario creado con éxito!");
        usuarioCreado.setMessage("Accede con tu usuario y contraseña");
        usuarioCreado.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Limpiar_Campos();
            }
        });
        AlertDialog DialogoNuevo=usuarioCreado.create();
        DialogoNuevo.show();
    }
    private void usuariosCreadosError(){
        AlertDialog.Builder usuarioCreado=new AlertDialog.Builder(this);
        usuarioCreado.setTitle("Error al crear usuario");
        usuarioCreado.setMessage("Inténtalo de nuevo");
        usuarioCreado.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Limpiar_Campos();
            }
        });
        AlertDialog DialogoNuevo=usuarioCreado.create();
        DialogoNuevo.show();
    }

    private void accesoFallido(){
        AlertDialog.Builder usuarioCreado=new AlertDialog.Builder(this);
        usuarioCreado.setTitle("Usuario y/o contraseña incorrectos");
        usuarioCreado.setMessage("Intenta de nuevo con los valores correctos");
        usuarioCreado.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog DialogoNuevo=usuarioCreado.create();
        DialogoNuevo.show();
    }

    private void Limpiar_Campos(){
        etUsuario.setText("");
        etContraseña.setText("");
        etUsuario.requestFocus();
    }

    private void cambiarActividad(){
        Intent accesoExitoso=new Intent(this,MainActivity.class);
        startActivity(accesoExitoso);
    }

}
