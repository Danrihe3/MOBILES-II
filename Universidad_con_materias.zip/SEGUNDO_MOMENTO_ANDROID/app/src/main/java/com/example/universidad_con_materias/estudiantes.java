package com.example.universidad_con_materias;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;




import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


import java.util.HashMap;
import java.util.Map;


public class estudiantes extends AppCompatActivity {


    FirebaseFirestore db = FirebaseFirestore.getInstance();
    EditText etCarnet,etNombre,etCarrera,etSemestre;
    Button btnBuscar,btnAdicionar,btnModificar,btnEliminar,btnCancelar;
    CheckBox cbActivo;
    String carnet,nombre,carrera,semestre,id_documento,coleccion="Alumnos";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.estudiantes);


        etCarnet=findViewById(R.id.etCarnet);
        etNombre=findViewById(R.id.etNombre);
        etCarrera=findViewById(R.id.etCarrera);
        etSemestre=findViewById(R.id.etSemestre);
        btnAdicionar=findViewById(R.id.btnAdicionar);
        btnBuscar=findViewById(R.id.btnBuscar);
        btnModificar=findViewById(R.id.btnModificar);
        btnEliminar=findViewById(R.id.btnEliminar);
        btnCancelar=findViewById(R.id.btnCancelar);
        cbActivo=findViewById(R.id.cbActivo);
        cbActivo.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        etNombre.setEnabled(false);
        etCarrera.setEnabled(false);
        etSemestre.setEnabled(false);
        btnAdicionar.setEnabled(false);
    }
    public void Adicionar(View view){
        carnet=etCarnet.getText().toString();
        nombre=etNombre.getText().toString();
        carrera=etCarrera.getText().toString();
        semestre=etSemestre.getText().toString();
        if(!carnet.isEmpty() && !nombre.isEmpty() && !carrera.isEmpty() && !semestre.isEmpty()){
            // Create a new user with a name
            Map<String, Object> alumno = new HashMap<>();
            alumno.put("Carnet", carnet);
            alumno.put("Nombre", nombre);
            alumno.put("Carrera", carrera);
            alumno.put("Semestre", semestre);
            alumno.put("Activo", "Si");


// Add a new document with a generated ID
            db.collection(coleccion)
                    .add(alumno)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            //Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                            Toast.makeText(estudiantes.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                            Limpiar_campos();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            //Log.w(TAG, "Error adding document", e);
                            Toast.makeText(estudiantes.this, "Error al generar el registro", Toast.LENGTH_SHORT).show();
                        }
                    });
        }else{
            Toast.makeText(this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
            etCarnet.requestFocus();
        }
    }


    public void Buscar(View view){
        carnet=etCarnet.getText().toString();
        if(!carnet.isEmpty()){
            db.collection(coleccion)
                    .whereEqualTo("Carnet",carnet)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                if(task.getResult().size()>0) {
                                    btnAdicionar.setEnabled(false);
                                    btnModificar.setEnabled(true);
                                    btnEliminar.setEnabled(true);
                                    cbActivo.setEnabled(true);
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        //Log.d(TAG, document.getId() + " => " + document.getData());
                                        id_documento = document.getId();
                                        etNombre.setText(document.getString("Nombre"));
                                        etCarrera.setText(document.getString("Carrera"));
                                        etSemestre.setText(document.getString("Semestre"));
                                        if (document.getString("Activo").equals("Si")) {
                                            cbActivo.setChecked(true);
                                        } else {
                                            cbActivo.setChecked(false);
                                        }
                                        etNombre.setEnabled(true);
                                        etCarrera.setEnabled(true);
                                        etSemestre.setEnabled(true);
                                    }
                                }else{
                                    CrearNuevosEstudiantes();
                                }
                            } else {
                                //Log.w(TAG, "Error getting documents.", task.getException());
                            }
                        }
                    });


        }else{
            Toast.makeText(this, "El número de carnet es requerido.", Toast.LENGTH_SHORT).show();
            etCarnet.requestFocus();
        }


    }

    public void Modificar(View view){
        carnet=etCarnet.getText().toString();
        nombre=etNombre.getText().toString();
        carrera=etCarrera.getText().toString();
        semestre=etSemestre.getText().toString();
        if(!carnet.isEmpty() && !nombre.isEmpty() && !carrera.isEmpty() && !semestre.isEmpty()){
            // Create a new user with a first and last name
            Map<String, Object> alumno = new HashMap<>();
            alumno.put("Carnet", carnet);
            alumno.put("Nombre", nombre);
            alumno.put("Carrera", carrera);
            alumno.put("Semestre", semestre);
            if(cbActivo.isChecked()){
                alumno.put("Activo","Si");
            }else{
                alumno.put("Activo","No");
            }


            db.collection(coleccion).document(id_documento)
                    .set(alumno)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(estudiantes.this,"Estudiante actualizado.",Toast.LENGTH_SHORT).show();
                            Limpiar_campos();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(estudiantes.this,"Error al actualizar.",Toast.LENGTH_SHORT).show();
                        }
                    });
        }else{
            Toast.makeText(this, "Todos los campos son obligatorios.", Toast.LENGTH_SHORT).show();
        }
    }


    private void Eliminar(){
        db.collection(coleccion).document(id_documento)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Limpiar_campos();
                        Toast.makeText(estudiantes.this,"Estudiante eliminado correctamente...",Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(estudiantes.this,"Error eliminando estudiante...",Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void Limpiar_campos(){
        etCarnet.setText("");
        etSemestre.setText("");
        etCarrera.setText("");
        etNombre.setText("");
        etCarnet.requestFocus();
        cbActivo.setChecked(false);
        cbActivo.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        etNombre.setEnabled(false);
        etCarrera.setEnabled(false);
        etSemestre.setEnabled(false);
        btnAdicionar.setEnabled(false);


    }
    public void Cancelar(View view){
        Limpiar_campos();
    }

    private void CrearNuevosEstudiantes(){
        AlertDialog.Builder CrearUsuario=new AlertDialog.Builder(this);
        CrearUsuario.setTitle("Estudiante no encontrado");
        CrearUsuario.setMessage("¿Deseas crear un nuevo estudiante?");
        CrearUsuario.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                etNombre.setEnabled(true);
                etCarrera.setEnabled(true);
                etSemestre.setEnabled(true);
                cbActivo.setEnabled(true);
                btnAdicionar.setEnabled(true);
                etNombre.requestFocus();
            }
        });
        CrearUsuario.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                etCarnet.requestFocus();
            }
        });

        AlertDialog DialogoNuevo=CrearUsuario.create();
        DialogoNuevo.show();
    }

    public void ConfirmarEliminar(View view){
        AlertDialog.Builder EliminarEstudiante=new AlertDialog.Builder(this);
        EliminarEstudiante.setTitle("Eliminar estudiante");
        EliminarEstudiante.setMessage("¿Estás seguro que deseas elminar el estudiante?");
        EliminarEstudiante.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Eliminar();
            }
        });
        EliminarEstudiante.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                etCarnet.requestFocus();
            }
        });

        AlertDialog DialogoNuevo=EliminarEstudiante.create();
        DialogoNuevo.show();
    }


}

