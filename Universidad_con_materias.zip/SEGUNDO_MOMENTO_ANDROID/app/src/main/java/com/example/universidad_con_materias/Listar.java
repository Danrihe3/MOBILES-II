package com.example.universidad_con_materias;

import static com.example.universidad_con_materias.R.id.rvEstudiantes;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Firebase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class Listar  extends AppCompatActivity {

    RecyclerView rvEstudiantes;
    ArrayList<ListadoEstudiantes> alEstudiantes;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.listado);

        rvEstudiantes=findViewById(R.id.rvEstudiantes);
        alEstudiantes=new ArrayList<>();

    }
}
