package com.example.universidad_con_materias;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class EstudiantesAdapter extends RecyclerView.Adapter <EstudiantesAdapter.estudianteViewHolder>{
    ArrayList<ListadoEstudiantes> alestudiante;

    public EstudiantesAdapter(ArrayList<ListadoEstudiantes> alestudiante) {
        this.alestudiante = alestudiante;
    }

    @NonNull
    @Override
    public EstudiantesAdapter.estudianteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.estudiantesresource,null,false);
        return new EstudiantesAdapter.estudianteViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull EstudiantesAdapter.estudianteViewHolder holder, int position) {
        holder.carnet.setText(alestudiante.get(position).getIdentificacion().toString());
        holder.nombre.setText(alestudiante.get(position).getNombre().toString());
        holder.carrera.setText(alestudiante.get(position).getCarrera().toString());
        holder.semestre.setText(alestudiante.get(position).getSemestre().toString());
        if (alestudiante.get(position).getActivo().equals("Si"))
            holder.activo.setChecked(true);
        else
            holder.activo.setChecked(false);
    }

    @Override
    public int getItemCount() {
        return alestudiante.size();
    }

    public static class estudianteViewHolder extends RecyclerView.ViewHolder {
        TextView carnet,nombre,carrera,semestre;
        CheckBox activo;
        public estudianteViewHolder(@NonNull View itemView) {
            super(itemView);
            //vincular los objetos con los objetos CardView
            carnet=itemView.findViewById(R.id.tvcarnet);
            nombre=itemView.findViewById(R.id.tvnombre);
            carrera=itemView.findViewById(R.id.tvcarrera);
            semestre=itemView.findViewById(R.id.tvsemestre);
            activo=itemView.findViewById(R.id.cbactivo);
        }
    }
}