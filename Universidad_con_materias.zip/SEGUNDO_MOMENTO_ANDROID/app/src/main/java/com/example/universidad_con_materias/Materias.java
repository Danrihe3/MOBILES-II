package com.example.universidad_con_materias;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;


public class Materias extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    EditText etCodMateria,etMateria,etAreaMateria,etCreditos;
    Button btnBuscar,btnAdicionar,btnModificar,btnEliminar,btnCancelar;
    CheckBox cbActivo;
    String AreaMateria,Materia,CodMateria,Creditos,Coleccion="Materias",id_materia;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.materias);

        etCodMateria=findViewById(R.id.etCodMateria);
        etMateria=findViewById(R.id.etMateria);
        etAreaMateria=findViewById(R.id.etAreaMateria);
        etCreditos=findViewById(R.id.etCreditos);
        btnBuscar=findViewById(R.id.btnBuscar);
        btnAdicionar=findViewById(R.id.btnAdicionar);
        btnModificar=findViewById(R.id.btnModificar);
        btnEliminar=findViewById(R.id.btnEliminar);
        btnCancelar=findViewById(R.id.btnCancelar);
        cbActivo=findViewById(R.id.cbActivo);
        cbActivo.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        etMateria.setEnabled(false);
        etAreaMateria.setEnabled(false);
        etCreditos.setEnabled(false);
        btnAdicionar.setEnabled(false);
        etCodMateria.requestFocus();


    }

    public void AdicionarMaterias(View view){
            CodMateria=etCodMateria.getText().toString();
            Materia=etMateria.getText().toString();
            AreaMateria=etAreaMateria.getText().toString();
            Creditos=etCreditos.getText().toString();
            if(!CodMateria.isEmpty() && !Materia.isEmpty() && !CodMateria.isEmpty() && !Creditos.isEmpty()){
                // Create a new user with a first and last name
                Map<String, Object> Materias = new HashMap<>();
                Materias.put("CodMateria", CodMateria);
                Materias.put("Materia", Materia);
                Materias.put("AreaMateria", AreaMateria);
                Materias.put("Creditos", Creditos);
                Materias.put("Activo", "Si");
// Add a new document with a generated ID
                db.collection(Coleccion)
                        .add(Materias)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                //Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                                Toast.makeText(Materias.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                                Limpiar_Campos();

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //Log.w(TAG, "Error adding document", e);
                                Toast.makeText(Materias.this, "Error al guardar el registro", Toast.LENGTH_SHORT).show();
                                etCodMateria.requestFocus();
                            }
                        });
        }else{
                Toast.makeText(this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
        }
    }

    public void BuscarMaterias(View view){
        CodMateria=etCodMateria.getText().toString();
        if(!CodMateria.isEmpty()){
            db.collection("Materias")
                    .whereEqualTo("CodMateria",CodMateria)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                if(task.getResult().size()>0) {
                                    btnAdicionar.setEnabled(false);
                                    btnModificar.setEnabled(true);
                                    btnEliminar.setEnabled(true);
                                    cbActivo.setEnabled(true);
                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                        //Log.d(TAG, document.getId() + " => " + document.getData());
                                        id_materia = document.getId();
                                        etMateria.setText(document.getString("Materia"));
                                        etAreaMateria.setText(document.getString("AreaMateria"));
                                        etCreditos.setText(document.getString("Creditos"));
                                        if (document.getString("Activo").equals("Si")) {
                                            cbActivo.setChecked(true);
                                        } else {
                                            cbActivo.setChecked(false);
                                        }
                                        etMateria.setEnabled(true);
                                        etAreaMateria.setEnabled(true);
                                        etCreditos.setEnabled(true);
                                    }
                                }else{
                                    CrearNuevasMaterias();
                                }
                            } else {
                                //Log.w(TAG, "Error getting documents.", task.getException());
                            }
                        }
                    });


        }else{
            Toast.makeText(this, "El número de carnet es requerido.", Toast.LENGTH_SHORT).show();
            etCodMateria.requestFocus();
        }
    }

    public void ModificarMaterias(View view){
        CodMateria=etCodMateria.getText().toString();
        Materia=etMateria.getText().toString();
        AreaMateria=etAreaMateria.getText().toString();
        Creditos=etCreditos.getText().toString();
        if(!CodMateria.isEmpty() && !Materia.isEmpty() && !AreaMateria.isEmpty() && !Creditos.isEmpty()){
            // Create a new user with a first and last name
            Map<String, Object> Materias = new HashMap<>();
            Materias.put("CodMateria", CodMateria);
            Materias.put("Materia", Materia);
            Materias.put("AreaMateria", AreaMateria);
            Materias.put("Creditos", Creditos);
            if(cbActivo.isChecked()){
                Materias.put("Activo","Si");
            }else{
                Materias.put("Activo","No");
            }


            db.collection("Materias").document(id_materia)
                    .set(Materias)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(Materias.this,"Materia actualizada.",Toast.LENGTH_SHORT).show();
                            Limpiar_Campos();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Materias.this,"Error al actualizar.",Toast.LENGTH_SHORT).show();
                        }
                    });
        }else{
            Toast.makeText(this, "Todos los campos son obligatorios.", Toast.LENGTH_SHORT).show();
        }
    }


    private void EliminarMaterias(){
        db.collection("Materias").document(id_materia)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Limpiar_Campos();
                        Toast.makeText(Materias.this,"Materia eliminada correctamente...",Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Materias.this,"Error eliminando materia...",Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void CancelarMaterias(View view){
        Limpiar_Campos();
    }

    private void Limpiar_Campos(){
        etCodMateria.setText("");
        etMateria.setText("");
        etAreaMateria.setText("");
        etCreditos.setText("");
        cbActivo.setChecked(false);
        cbActivo.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        etMateria.setEnabled(false);
        etAreaMateria.setEnabled(false);
        etCreditos.setEnabled(false);
        btnAdicionar.setEnabled(false);
        etCodMateria.requestFocus();
    }

    private void CrearNuevasMaterias(){
        AlertDialog.Builder CrearUsuario=new AlertDialog.Builder(this);
        CrearUsuario.setTitle("Materia no encontrada");
        CrearUsuario.setMessage("¿Deseas crear una nueva materia?");
        CrearUsuario.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                etMateria.setEnabled(true);
                etAreaMateria.setEnabled(true);
                etCreditos.setEnabled(true);
                cbActivo.setEnabled(true);
                btnAdicionar.setEnabled(true);
                etMateria.requestFocus();
            }
        });
        CrearUsuario.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                etCodMateria.requestFocus();
            }
        });

        AlertDialog DialogoNuevo=CrearUsuario.create();
        DialogoNuevo.show();
    }

    public void ConfirmarEliminarMaterias(View view){
        AlertDialog.Builder CrearUsuario=new AlertDialog.Builder(this);
        CrearUsuario.setTitle("Eliminar Materia");
        CrearUsuario.setMessage("¿Estás seguro que deseas elminar la materia?");
        CrearUsuario.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EliminarMaterias();
            }
        });
        CrearUsuario.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                etCodMateria.requestFocus();
            }
        });

        AlertDialog DialogoNuevo=CrearUsuario.create();
        DialogoNuevo.show();
    }

}


